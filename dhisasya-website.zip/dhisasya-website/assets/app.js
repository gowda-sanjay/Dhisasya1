// Language strings (English & Kannada)
const LANG_STRINGS = {
  en: {
    toggleLabel: " Kannada ↔ English",
    goDashboard: "Dashboard",
    navLive: "Live Sensor Data",
    navCrop: "Crop Recommendation",
    navFert: "Fertilizer Suggestion",
    navGraphs: "Yield Graphs",
    navDisease: "Disease Recognition",
    navRain: "Rain Alerts",
    navIrrigation: "Irrigation Control",
    navAlerts: "SMS/Call Alerts",
    navVoice: "Voice Assistant",
    navMarket: "Market Prices",
    rainWarning: "Rain detected by sensor! Check irrigation schedule.",
    liveTitle: "Live Sensor Data",
    temp: "Temperature",
    humidity: "Humidity",
    soil: "Soil Moisture",
    ph: "pH",
    rain: "Rain",
    waterLevel: "Water Level",
    graphsTitle: "Yield & Soil Moisture Trends",
    cropTitle: "Crop Recommendation",
    fertTitle: "Fertilizer Suggestion",
    diseaseTitle: "Disease Recognition",
    diseaseNote: "Upload or capture a leaf image in the mobile app. This website shows results only. (Model plug-in placeholder.)",
    runDemo: "Run Demo",
    rainTitle: "Rain Sensor Alerts",
    rainDesc: "Banner appears when rain is detected (sensor value > 0). Threshold configurable in app.js.",
    irrigTitle: "Irrigation Control",
    irrigNote: "Connect your relay/valve controller via API. Below is a safe simulation.",
    turnOn: "Turn ON",
    turnOff: "Turn OFF",
    statusOff: "Status: OFF",
    alertsTitle: "SMS/Call Alerts",
    alertsNote: "Integrate Twilio/MSG91 later. This section lists simulated alert events triggered by thresholds.",
    voiceTitle: "Voice Assistant",
    voiceNote: "Use simple voice commands like “open live data”, “show graphs”, “switch to Kannada”.",
    startListening: "Start Listening",
    marketTitle: "Market Prices",
    crop: "Crop",
    minPrice: "Min Price (₹/quintal)",
    maxPrice: "Max Price (₹/quintal)",
    market: "Market",
    team: "Team:",
    contact: "Contact:",
  },
  kn: {
    toggleLabel: " ಕನ್ನಡ ↔ English",
    goDashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    navLive: "ಸ್ಥಿತಿಗತಿ ಸಂವೇದಕ ಮಾಹಿತಿ",
    navCrop: "ಬೆಳೆ ಶಿಫಾರಸು",
    navFert: "ರಸಗೊಬ್ಬರ ಶಿಫಾರಸು",
    navGraphs: "ಉತ್ಪಾದನೆ ಗ್ರಾಫ್‌ಗಳು",
    navDisease: "ರೋಗ ಗುರುತು",
    navRain: "ಮಳೆ ಎಚ್ಚರಿಕೆ",
    navIrrigation: "ನೀರಾವರಿ ನಿಯಂತ್ರಣ",
    navAlerts: "SMS/ಕಾಲ್ ಎಚ್ಚರಿಕೆ",
    navVoice: "ವಾಯ್ಸ್ ಅಸಿಸ್ಟೆಂಟ್",
    navMarket: "ಮಾರುಕಟ್ಟೆ ಬೆಲೆ",
    rainWarning: "ಮಳೆ ಸಂವೇದಕ ಪತ್ತೆ! ನೀರಾವರಿ ವೇಳಾಪಟ್ಟಿ ಪರಿಶೀಲಿಸಿ.",
    liveTitle: "ಸ್ಥಿತಿಗತಿ ಸಂವೇದಕ ಮಾಹಿತಿ",
    temp: "ತಾಪಮಾನ",
    humidity: "ಆದ್ರತೆ",
    soil: "ಮಣ್ಣಿನ ತೇವಾಂಶ",
    ph: "pH",
    rain: "ಮಳೆ",
    waterLevel: "ನೀರಿನ ಮಟ್ಟ",
    graphsTitle: "ಉತ್ಪಾದನೆ & ಮಣ್ಣಿನ ತೇವಾಂಶ ಟ್ರೆಂಡ್",
    cropTitle: "ಬೆಳೆ ಶಿಫಾರಸು",
    fertTitle: "ರಸಗೊಬ್ಬರ ಶಿಫಾರಸು",
    diseaseTitle: "ರೋಗ ಗುರುತು",
    diseaseNote: "ಮೊಬೈಲ್ ಆಪ್‌ನಲ್ಲಿ ಎಲೆಯ ಚಿತ್ರವನ್ನು ಅಪ್ಲೋಡ್/ಕ್ಯಾಪ್ಚರ್ ಮಾಡಿ. ಇಲ್ಲಿ ಫಲಿತಾಂಶ ಮಾತ್ರ (ಮೋಡಲ್ ಪ್ಲಗಿನ್ ಪ್ಲೇಸ್‌ಹೋಲ್ಡರ್).",
    runDemo: "ಡೆಮೋ ರನ್",
    rainTitle: "ಮಳೆ ಸಂವೇದಕ ಎಚ್ಚರಿಕೆ",
    rainDesc: "ಮಳೆ ಮೌಲ್ಯ > 0 ಆಗಿದ್ದಾಗ ಬ್ಯಾನರ್ ತೋರಿಸುತ್ತದೆ. ಥ್ರೆಶೋಲ್ಡ್ ಅನ್ನು app.js ನಲ್ಲಿ ಬದಲಾಯಿಸಿ.",
    irrigTitle: "ನೀರಾವರಿ ನಿಯಂತ್ರಣ",
    irrigNote: "API ಮೂಲಕ ರಿಲೇ/ವಾಲ್ವ್ ಸಂಪರ್ಕಿಸಿ. ಇಲ್ಲಿ ಸುರಕ್ಷಿತ ಅನುಕರಣ (Simulation).",
    turnOn: "ಆನ್ ಮಾಡಿ",
    turnOff: "ಆಫ್ ಮಾಡಿ",
    statusOff: "ಸ್ಥಿತಿ: OFF",
    alertsTitle: "SMS/ಕಾಲ್ ಎಚ್ಚರಿಕೆ",
    alertsNote: "Twilio/MSG91 ನಂತರ ಹಾಕಿ. ಇಲ್ಲಿ ಥ್ರೆಶೋಲ್ಡ್‌ನಿಂದ ಬಂದ ಡೆಮೋ ಎಚ್ಚರಿಕೆಗಳು.",
    voiceTitle: "ವಾಯ್ಸ್ ಅಸಿಸ್ಟೆಂಟ್",
    voiceNote: "“open live data”, “show graphs”, “switch to Kannada” ಅಂತೆ ಸರಳ ಕಮಾಂಡ್ ಬಳಸಿ.",
    startListening: "ಶ್ರವಣ ಆರಂಭಿಸಿ",
    marketTitle: "ಮಾರುಕಟ್ಟೆ ಬೆಲೆ",
    crop: "ಬೆಳೆ",
    minPrice: "ಕನಿಷ್ಠ ಬೆಲೆ (₹/ಕ್ವಿಂಟಲ್)",
    maxPrice: "ಗರಿಷ್ಠ ಬೆಲೆ (₹/ಕ್ವಿಂಟಲ್)",
    market: "ಮಾರುಕಟ್ಟೆ",
    team: "ತಂಡ:",
    contact: "ಸಂಪರ್ಕ:",
  }
};

// Language toggle logic
const i18nApply = (lang) => {
  const dict = LANG_STRINGS[lang] ?? LANG_STRINGS.en;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (dict[key]) el.textContent = dict[key];
  });
  localStorage.setItem("dhisasya_lang", lang);
};
const initLang = () => {
  const saved = localStorage.getItem("dhisasya_lang") || "en";
  i18nApply(saved);
  document.getElementById("langToggle").onclick = () => {
    const next = (localStorage.getItem("dhisasya_lang") || "en") === "en" ? "kn" : "en";
    i18nApply(next);
  };
};

// Sensor simulation and state
const state = {
  sensors: {
    temperature: 28.5,
    humidity: 60,
    soilMoisture: 35,
    ph: 6.8,
    rain: 0,
    waterLevel: 65
  },
  irrigOn: false,
  alerts: []
};

const RAIN_THRESHOLD = 0; // > 0 means raining
const SOIL_DRY_THRESHOLD = 30; // below => dry

function renderSensors(){
  document.getElementById("val-temp").textContent = `${state.sensors.temperature.toFixed(1)} °C`;
  document.getElementById("val-humidity").textContent = `${state.sensors.humidity.toFixed(0)} %`;
  document.getElementById("val-soil").textContent = `${state.sensors.soilMoisture.toFixed(0)} %`;
  document.getElementById("val-ph").textContent = `${state.sensors.ph.toFixed(1)}`;
  document.getElementById("val-rain").textContent = state.sensors.rain > 0 ? "Yes" : "No";
  document.getElementById("val-water").textContent = `${state.sensors.waterLevel.toFixed(0)} %`;

  const banner = document.getElementById("rainBanner");
  if(state.sensors.rain > RAIN_THRESHOLD){
    banner.classList.remove("hidden");
    pushAlert("Rain detected. Irrigation paused.");
  } else {
    banner.classList.add("hidden");
  }
}

function recommendCrop(){
  // Simple rule-based recommendation demo
  const {temperature, humidity, soilMoisture, ph} = state.sensors;
  let rec = "";
  if(ph >= 6 && ph <= 7.5 && soilMoisture >= 35 && humidity >= 50){
    rec = "Paddy, Maize, Ragi (finger millet) are suitable now.";
  } else if (ph >= 5.5 && ph <= 6.5 && soilMoisture < 35){
    rec = "Groundnut, Red Gram (Tur), Sunflower fit drier conditions.";
  } else {
    rec = "Mix cropping and soil testing advised; try resilient crops like Ragi/Red Gram.";
  }
  document.getElementById("cropRec").textContent = rec;
}

function recommendFertilizer(){
  const {ph, soilMoisture} = state.sensors;
  let rec = [];
  if(ph < 6) rec.push("Add Lime/Dolomite to raise pH.");
  if(ph > 7.5) rec.push("Use elemental sulphur or ammonium sulphate to lower pH.");
  if(soilMoisture < SOIL_DRY_THRESHOLD) rec.push("Apply moisture-retaining organic matter/compost.");
  if(rec.length === 0) rec.push("Balanced NPK based on soil test; maintain pH 6.5–7.0.");
  document.getElementById("fertRec").textContent = rec.join(" ");
}

// Alerts
function pushAlert(text){
  const time = new Date().toLocaleTimeString();
  state.alerts.unshift(`[${time}] ${text}`);
  const ul = document.getElementById("alertList");
  ul.innerHTML = state.alerts.slice(0, 6).map(t => `<li>${t}</li>`).join("");
}

// Irrigation sim
function updateIrrigationButtons(){
  const st = document.getElementById("irrigStatus");
  if(state.irrigOn){
    st.textContent = "Status: ON";
    st.style.color = "var(--accent)";
  } else {
    st.textContent = (LANG_STRINGS[localStorage.getItem("dhisasya_lang") || "en"].statusOff);
    st.style.color = "var(--text)";
  }
}

// Voice Assistant (very basic)
function initVoice(){
  const btn = document.getElementById("btnSpeak");
  const status = document.getElementById("voiceStatus");
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SpeechRecognition){
    status.textContent = "Speech recognition not supported in this browser.";
    return;
  }
  const rec = new SpeechRecognition();
  rec.lang = (localStorage.getItem("dhisasya_lang") || "en") === "kn" ? "kn-IN" : "en-US";
  rec.onresult = (e)=>{
    const txt = e.results[0][0].transcript.toLowerCase();
    status.textContent = `"${txt}"`;
    if(txt.includes("open live") || txt.includes("live data")) location.hash = "#live";
    if(txt.includes("graphs")) location.hash = "#graphs";
    if(txt.includes("crop")) location.hash = "#crop";
    if(txt.includes("kannada")) { i18nApply("kn"); }
    if(txt.includes("english")) { i18nApply("en"); }
  };
  btn.onclick = ()=>{
    status.textContent = "Listening...";
    rec.start();
  };
}

// Charts
let yieldChart, moistureChart;
function initCharts(){
  const yc = document.getElementById("yieldChart");
  const mc = document.getElementById("moistureChart");
  const labels = Array.from({length: 12}, (_,i)=>`M${i+1}`);
  yieldChart = new Chart(yc, {
    type:'line',
    data:{labels, datasets:[{label:'Yield (q/ha)', data: labels.map(()=> 18 + Math.random()*6)}]},
    options:{responsive:true, maintainAspectRatio:false}
  });
  moistureChart = new Chart(mc, {
    type:'line',
    data:{labels, datasets:[{label:'Soil Moisture (%)', data: labels.map(()=> 30 + Math.random()*20)}]},
    options:{responsive:true, maintainAspectRatio:false}
  });
}

function updateChartsTick(){
  const shiftPush = (arr,val)=>{arr.shift(); arr.push(val);};
  shiftPush(yieldChart.data.datasets[0].data, 18 + Math.random()*6);
  shiftPush(moistureChart.data.datasets[0].data, state.sensors.soilMoisture + (Math.random()*4-2));
  yieldChart.update();
  moistureChart.update();
}

// Market prices (static demo data)
const MARKET_DATA = [
  {crop:"Ragi", min:2500, max:3100, market:"Kolar"},
  {crop:"Tomato", min:700, max:1400, market:"Chikkaballapur"},
  {crop:"Groundnut", min:5800, max:6500, market:"Tumakuru"},
  {crop:"Tur (Red Gram)", min:9000, max:10500, market:"Kalaburagi"},
];

function renderMarket(){
  const tb = document.querySelector("#marketTable tbody");
  tb.innerHTML = MARKET_DATA.map(r => `<tr><td>${r.crop}</td><td>${r.min}</td><td>${r.max}</td><td>${r.market}</td></tr>`).join("");
}

// Disease demo
function runDiseaseDemo(){
  const el = document.getElementById("diseaseOutput");
  const options = ["Blight risk low (12%)","Leaf spot moderate (38%)","Rust high risk (71%)"];
  el.textContent = options[Math.floor(Math.random()*options.length)];
}

// TODO: Replace simulated sensor updates with real API/WebSocket data.
function updateSensors(){
  // simulate gentle drift
  state.sensors.temperature += (Math.random()*2-1)*0.4;
  state.sensors.humidity += (Math.random()*2-1)*1.2;
  state.sensors.soilMoisture += (Math.random()*2-1)*1.5 * (state.irrigOn ? 1.5 : 1);
  state.sensors.ph += (Math.random()*2-1)*0.03;
  // occasionally rain
  state.sensors.rain = Math.random() < 0.1 ? 1 : 0;
  // water level
  state.sensors.waterLevel += (state.irrigOn ? -0.6 : -0.2);
  if(state.sensors.waterLevel < 10) {
    pushAlert("Low water level! Refill tank.");
  }
  // thresholds => alerts
  if(state.sensors.soilMoisture < SOIL_DRY_THRESHOLD && !state.irrigOn){
    pushAlert("Soil is dry. Consider irrigation.");
  }
  renderSensors();
  recommendCrop();
  recommendFertilizer();
  updateChartsTick();
}

function applySensorPayload(payload){
  // If you fetch data from your server, pass it here.
  if(payload?.sensors){
    Object.assign(state.sensors, payload.sensors);
    renderSensors();
    recommendCrop();
    recommendFertilizer();
  }
}

function initIrrigationControls(){
  document.getElementById("btnIrrOn").onclick = ()=>{
    state.irrigOn = true;
    updateIrrigationButtons();
    pushAlert("Irrigation turned ON");
  };
  document.getElementById("btnIrrOff").onclick = ()=>{
    state.irrigOn = false;
    updateIrrigationButtons();
    pushAlert("Irrigation turned OFF");
  };
}

function boot(){
  initLang();
  renderSensors();
  recommendCrop();
  recommendFertilizer();
  renderMarket();
  initIrrigationControls();
  initCharts();
  initVoice();

  document.getElementById("btnDiseaseDemo").onclick = runDiseaseDemo;

  // Sensor simulation tick (every 3s)
  setInterval(updateSensors, 3000);
}

document.addEventListener("DOMContentLoaded", boot);
