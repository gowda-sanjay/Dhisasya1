# Dhisasya – Intelligent Crop System (GitHub Pages)

A bilingual (Kannada/English) static website that mirrors the core features of your Dhisasya mobile app. Built with plain **HTML, CSS, and JavaScript** and deployable on **GitHub Pages**.

## ✅ Features
- Header with project logo + title in **Kannada & English**.
- Navigation bar with **Font Awesome** icons.
- **Language toggle** (Kannada ↔ English).
- **Live Sensor Data** (simulated + easy to connect to API/WebSocket).
- **Yield** & **Soil Moisture** graphs using **Chart.js**.
- Crop & fertilizer recommendations (rule-based demo).
- Rain sensor alert banner.
- Sections for: Disease Recognition, Irrigation Control, SMS/Call Alerts, Voice Assistant, Market Prices.
- Footer with team names + contact email.

> Everything is client-side (no server). You can plug in your own API later by editing `assets/app.js`.

---

## 🛠 Local Setup (VS Code)
1. Download this folder and open it in **VS Code**.
2. Install the extension **“Live Server”** (by Ritwick Dey) to preview.
3. Right-click `index.html` → **Open with Live Server**.

---

## 🚀 Deploy to GitHub Pages
1. Create a new **public** repo on GitHub (e.g., `dhisasya-website`).
2. Upload (or push) all files in this folder to the repo root.
3. On GitHub: **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: `main` (root)**.
4. Wait ~1–2 minutes, then open the published URL shown on the Pages screen.

---

## 🔌 Integrate Real Sensors Later
Open `assets/app.js` and look for the `// TODO: Replace simulated sensor updates` section.
- Replace the `setInterval(updateSensors, 3000)` loop with your fetch/WebSocket code.
- Example REST shape expected by `applySensorPayload(payload)`:
```json
{
  "sensors": {
    "temperature": 29.4,
    "humidity": 62,
    "soilMoisture": 41,
    "ph": 6.5,
    "rain": 0,
    "waterLevel": 70
  }
}
```

---

## 📁 Project Structure
```
/ (repo root)
├── index.html
├── assets/
│   ├── style.css
│   └── app.js
└── README.md
```

---

## ✍️ Credits
- Icons: [Font Awesome](https://fontawesome.com/)
- Charts: [Chart.js](https://www.chartjs.org/)
- Kannada font: Noto Sans Kannada

---

## 🧪 Quick Tips
- You can change team names and email in the footer in `index.html`.
- Strings for both languages live in `assets/app.js` under `LANG_STRINGS`.
- The site remembers the last selected language via `localStorage`.
